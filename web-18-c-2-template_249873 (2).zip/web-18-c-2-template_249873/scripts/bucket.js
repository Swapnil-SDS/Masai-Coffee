// On clicking remove button the item should be removed from DOM as well as localstorage.
let data = JSON.parse(localStorage.getItem("coffee"));


total(data);
storingalldata(data);

let new_container = document.getElementById("coffee");
function storingalldata(data) {
  data.forEach(function (el, index) {
    let new_container = document.getElementById("total-div");
    let div = document.createElement("div");
    let img = document.createElement("img");
    img.src = el.image;
    
    let h2 = document.createElement("h2");
    h2.innerText = el.title;

    let p = document.createElement("p");
    p.innerText = `${el.price}Rs`;

    let btn = document.createElement("button");
    btn.setAttribute("id", "remove_coffee");
    btn.innerText = "Add to Bucket";
    btn.innerText = "Remove from Bucket";
    btn.addEventListener("click", function () {
      remove(el,index);
    });

    div.append(img, h2, p, btn);
    new_container.append(div);
  
  });
}

function remove(el,index){
    // new_container.innerHTML="";
    data.splice(index,1);
    console.log(data)
    localStorage.setItem("coffee",JSON.stringify(data))
    storingalldata(data)
    total(data)
}

function total(data) {
  let sum = 0;
  for (let i = 0; i < data.length; i++) {
    sum += data[i].price;
  }
  console.log(sum)
  let total = document.getElementById("total_amount");
  total.innerText = sum;
}

function checkout() {
  window.location.href = "./checkout.html";
}