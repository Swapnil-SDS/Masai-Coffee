// Add the coffee to local storage with key "coffee"

storedata();
async function storedata(){
    try{
        let res = await fetch("https://masai-mock-api.herokuapp.com/coffee/menu");
        let data=await res.json()
        console.log(data.menu.data)
        storingalldata(data.menu.data)
    }catch(err){ 
    }
}
let container = document.getElementById("menu");
function storingalldata(data){
    data.forEach(function(el){
      let div = document.createElement("div");
      let img = document.createElement("img");
      img.src = el.image;

      let h2 = document.createElement("h2");
      h2.innerText=el.title

      let p=document.createElement("p")
      p.innerText = `${el.price}Rs`;

      let btn = document.createElement("button");
      btn.setAttribute("id", "add_to_bucket");
      btn.innerText="Add to Bucket";
      btn.addEventListener("click",function(){
      add(el)
      })
      div.append(img,h2,p,btn)
      container.append(div)
    })
}
// var \arr= ;
let arr= JSON.parse(localStorage.getItem("coffee")) || [];
document.querySelector("#coffee_count").innerHTML=arr.length
function add(el) {
  arr.push(el);
  document.querySelector("#coffee_count").innerHTML=arr.length;
  localStorage.setItem("coffee",JSON.stringify(arr))
  }
  function goto(){
  window.location.href="./bucket.html"
  }
