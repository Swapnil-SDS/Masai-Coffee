let total_time = document.querySelector("form").addEventListener("submit", function (event) {
    event.preventDefault();
    let i = -1;
    total_time = setInterval(function () {
      i = i + 1;

      if (i === 0) {
        alert("Your order is accepted ");
      }
      if (i === 3) {
        alert("Your order is being Prepare");
      }
      if (i === 8) {
        alert("Your order is being  packed  ");
      }
      if (i === 10) {
        alert("Your order is out for delivery");
      }

      if (i === 12) {
        alert(" Order delivered");
      }
    }, 1000);
  });



    
